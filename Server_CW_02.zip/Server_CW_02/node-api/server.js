// node-api/server.js

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();

// ── Security Middleware ────────────────────────────────────────────────────────
app.use(helmet());

// Allow CodeIgniter frontend to call this API
app.use(cors({
    origin: [
        'http://localhost',
        'http://localhost/Server_CW/Server_CW_02/Codeigniter',
        'http://127.0.0.1'
    ],
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true
}));

// Global rate limiter
const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 200,
    message: { success: false, message: 'Too many requests, slow down.' }
});
app.use(globalLimiter);

// Body parsers
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true }));

app.set('trust proxy', 1);

// ── Routes ────────────────────────────────────────────────────────────────────
const authRoutes = require('./routes/authRoutes');
app.use('/api/auth', authRoutes);

// Health check - visit http://localhost:3000/api/health to confirm running
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        message: 'Alumni Dashboard API is running ✅',
        time: new Date().toISOString()
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: `Cannot ${req.method} ${req.path}`
    });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error('Server Error:', err.message);
    res.status(500).json({
        success: false,
        message: 'Internal server error.'
    });
});

// ── Start ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log('╔══════════════════════════════════════════╗');
    console.log('║   Alumni Dashboard API - Node.js         ║');
    console.log('╠══════════════════════════════════════════╣');
    console.log(`║  Running on : http://localhost:${PORT}      ║`);
    console.log(`║  Health     : http://localhost:${PORT}/api/health ║`);
    console.log(`║  Env        : ${process.env.NODE_ENV || 'development'}                 ║`);
    console.log('╚══════════════════════════════════════════╝');
});