// node-api/routes/authRoutes.js

const express = require('express');
const router = express.Router();

const authController = require('../controllers/authController');
const { verifyToken } = require('../middleware/authMiddleware');
const {
    validateRegistration,
    validateLogin,
    validateForgotPassword,
    validateResetPassword
} = require('../middleware/validationMiddleware');
const rateLimit = require('express-rate-limit');

// ─── Rate Limiters (security against brute force) ─────────────────────────────

// Strict limit on login attempts
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,   // 15 minutes
    max: 5,                       // max 5 login attempts
    message: {
        success: false,
        message: 'Too many login attempts. Please try again in 15 minutes.'
    },
    standardHeaders: true,
    legacyHeaders: false
});

// Moderate limit on registration
const registerLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,   // 1 hour
    max: 3,                       // max 3 registrations per hour per IP
    message: {
        success: false,
        message: 'Too many registration attempts. Please try again later.'
    }
});

// Limit on password reset requests
const resetLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,   // 1 hour
    max: 3,
    message: {
        success: false,
        message: 'Too many reset requests. Please try again in an hour.'
    }
});

// ─── Auth Routes ──────────────────────────────────────────────────────────────

// Register new user (university email required)
router.post('/register', registerLimiter, validateRegistration, authController.register);

// Verify email with token from email link
router.get('/verify-email/:token', authController.verifyEmail);

// Resend verification email
router.post('/resend-verification', authController.resendVerification);

// Login with email and password
router.post('/login', loginLimiter, validateLogin, authController.login);

// Logout (requires valid token)
router.post('/logout', verifyToken, authController.logout);

// Request password reset email
router.post('/forgot-password', resetLimiter, validateForgotPassword, authController.forgotPassword);

// Submit new password with reset token
router.post('/reset-password/:token', validateResetPassword, authController.resetPassword);

// Get current user's profile (protected)
router.get('/me', verifyToken, authController.getProfile);

module.exports = router;