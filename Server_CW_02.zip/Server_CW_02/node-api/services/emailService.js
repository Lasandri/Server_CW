// node-api/services/emailService.js

const nodemailer = require('nodemailer');
require('dotenv').config();

// Create reusable transporter using SMTP
const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: process.env.EMAIL_SECURE === 'true',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD
    }
});

/**
 * Send email verification link to new users
 * @param {string} toEmail - recipient email address
 * @param {string} fullName - user's full name
 * @param {string} token - unique verification token
 */
async function sendVerificationEmail(toEmail, fullName, token) {
    // Build verification URL pointing to CodeIgniter controller
    const verifyUrl = `${process.env.APP_URL}/auth/verify_email/${token}`;

    const mailOptions = {
        from: `"Alumni Dashboard" <${process.env.EMAIL_FROM}>`,
        to: toEmail,
        subject: 'Verify Your Email - Alumni Analytics Dashboard',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <div style="background: #2c3e50; padding: 20px; text-align: center;">
                    <h1 style="color: white; margin: 0;">Alumni Analytics Dashboard</h1>
                </div>
                <div style="padding: 30px; background: #f9f9f9;">
                    <h2>Hello, ${fullName}!</h2>
                    <p>Thank you for registering. Please verify your university email address 
                    by clicking the button below.</p>
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="${verifyUrl}" 
                           style="background: #3498db; color: white; padding: 15px 30px; 
                                  text-decoration: none; border-radius: 5px; font-size: 16px;">
                            Verify Email Address
                        </a>
                    </div>
                    <p style="color: #666; font-size: 14px;">
                        This link expires in <strong>24 hours</strong>.
                    </p>
                    <p style="color: #666; font-size: 14px;">
                        If you did not register, please ignore this email.
                    </p>
                    <hr style="border: 1px solid #eee; margin: 20px 0;">
                    <p style="color: #999; font-size: 12px;">
                        Link not working? Copy and paste this URL:<br>
                        <a href="${verifyUrl}">${verifyUrl}</a>
                    </p>
                </div>
            </div>
        `
    };

    await transporter.sendMail(mailOptions);
    console.log(`✉️  Verification email sent to ${toEmail}`);
}

/**
 * Send password reset link
 * @param {string} toEmail - recipient email address
 * @param {string} fullName - user's full name
 * @param {string} token - unique reset token
 */
async function sendPasswordResetEmail(toEmail, fullName, token) {
    const resetUrl = `${process.env.APP_URL}/auth/reset_password/${token}`;

    const mailOptions = {
        from: `"Alumni Dashboard" <${process.env.EMAIL_FROM}>`,
        to: toEmail,
        subject: 'Password Reset - Alumni Analytics Dashboard',
        html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <div style="background: #2c3e50; padding: 20px; text-align: center;">
                    <h1 style="color: white; margin: 0;">Alumni Analytics Dashboard</h1>
                </div>
                <div style="padding: 30px; background: #f9f9f9;">
                    <h2>Password Reset Request</h2>
                    <p>Hello ${fullName}, we received a request to reset your password.</p>
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="${resetUrl}" 
                           style="background: #e74c3c; color: white; padding: 15px 30px; 
                                  text-decoration: none; border-radius: 5px; font-size: 16px;">
                            Reset My Password
                        </a>
                    </div>
                    <p style="color: #666; font-size: 14px;">
                        ⚠️ This link expires in <strong>1 hour</strong>.
                    </p>
                    <p style="color: #666; font-size: 14px;">
                        If you did NOT request a password reset, ignore this email. 
                        Your password will remain unchanged.
                    </p>
                </div>
            </div>
        `
    };

    await transporter.sendMail(mailOptions);
    console.log(`✉️  Password reset email sent to ${toEmail}`);
}

module.exports = { sendVerificationEmail, sendPasswordResetEmail };