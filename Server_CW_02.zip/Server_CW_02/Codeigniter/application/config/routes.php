<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes with
| underscores in the controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/


// Default route - goes to login page
$route['default_controller'] = 'Auth';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

// Auth routes
$route['auth']                           = 'Auth/login';
$route['auth/login']                     = 'Auth/login';
$route['auth/login_submit']              = 'Auth/login_submit';
$route['auth/register']                  = 'Auth/register';
$route['auth/register_submit']           = 'Auth/register_submit';
$route['auth/logout']                    = 'Auth/logout';
$route['auth/verify_email/(:any)']       = 'Auth/verify_email/$1';
$route['auth/resend_verification']       = 'Auth/resend_verification';
$route['auth/resend_verification_submit']= 'Auth/resend_verification_submit';
$route['auth/forgot_password']           = 'Auth/forgot_password';
$route['auth/forgot_password_submit']    = 'Auth/forgot_password_submit';
$route['auth/reset_password/(:any)']     = 'Auth/reset_password/$1';
$route['auth/reset_password_submit']     = 'Auth/reset_password_submit';

// Dashboard (protected)
$route['dashboard']                      = 'Dashboard/index';