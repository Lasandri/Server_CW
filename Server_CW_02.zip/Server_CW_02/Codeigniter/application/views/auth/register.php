<?php
// Codeigniter/application/views/auth/register.php
$page_title = 'Register - Alumni Dashboard';
$this->load->view('layouts/auth_header');
?>

<div class="row justify-content-center w-100">
    <div class="col-12">
        <div class="auth-card mx-auto">

            <!-- Logo -->
            <div class="auth-logo">
                <i class="fas fa-university fa-3x text-primary mb-3"></i>
                <h2>Alumni Dashboard</h2>
                <p>Create your university account</p>
            </div>

            <!-- Flash Messages -->
            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    <?php echo $this->session->flashdata('error'); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- API Error -->
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Field Errors from API -->
            <?php if (isset($field_errors) && !empty($field_errors)): ?>
                <div class="alert alert-warning">
                    <ul class="mb-0">
                        <?php foreach ($field_errors as $fe): ?>
                            <li><?php echo htmlspecialchars($fe['msg']); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Registration Form -->
            <?php echo form_open('auth/register_submit', ['class' => 'needs-validation', 'novalidate' => '']); ?>

                <!-- Full Name -->
                <div class="mb-3">
                    <label for="full_name" class="form-label fw-semibold">Full Name</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-user text-muted"></i>
                        </span>
                        <input type="text" 
                               class="form-control" 
                               id="full_name" 
                               name="full_name"
                               placeholder="John Smith"
                               value="<?php echo set_value('full_name'); ?>"
                               required>
                    </div>
                </div>

                <!-- University Email -->
                <div class="mb-3">
                    <label for="email" class="form-label fw-semibold">University Email</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-envelope text-muted"></i>
                        </span>
                        <input type="email" 
                               class="form-control" 
                               id="email" 
                               name="email"
                               placeholder="w123456789@my.westminster.ac.uk"
                               value="<?php echo set_value('email'); ?>"
                               required>
                    </div>
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        Only university email addresses (@my.westminster.ac.uk) are accepted
                    </small>
                </div>

                <!-- Password -->
                <div class="mb-3">
                    <label for="password" class="form-label fw-semibold">Password</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-lock text-muted"></i>
                        </span>
                        <input type="password" 
                               class="form-control" 
                               id="password" 
                               name="password"
                               placeholder="Min. 8 characters"
                               required
                               oninput="checkPasswordStrength(this.value)">
                        <button class="btn btn-outline-secondary" type="button" 
                                onclick="togglePassword('password')">
                            <i class="fas fa-eye" id="pwd-icon"></i>
                        </button>
                    </div>
                    <!-- Password strength bar -->
                    <div class="password-strength" id="strength-bar"></div>
                    <small id="strength-text" class="text-muted"></small>
                    <!-- Requirements checklist -->
                    <ul class="list-unstyled mt-2" id="pwd-requirements" style="font-size:12px;">
                        <li id="req-length"><i class="fas fa-times text-danger me-1"></i>At least 8 characters</li>
                        <li id="req-upper"><i class="fas fa-times text-danger me-1"></i>One uppercase letter</li>
                        <li id="req-lower"><i class="fas fa-times text-danger me-1"></i>One lowercase letter</li>
                        <li id="req-number"><i class="fas fa-times text-danger me-1"></i>One number</li>
                        <li id="req-special"><i class="fas fa-times text-danger me-1"></i>One special character (@$!%*?&)</li>
                    </ul>
                </div>

                <!-- Confirm Password -->
                <div class="mb-4">
                    <label for="confirm_password" class="form-label fw-semibold">Confirm Password</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-lock text-muted"></i>
                        </span>
                        <input type="password" 
                               class="form-control" 
                               id="confirm_password" 
                               name="confirm_password"
                               placeholder="Repeat password"
                               required
                               oninput="checkPasswordMatch()">
                        <button class="btn btn-outline-secondary" type="button"
                                onclick="togglePassword('confirm_password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div id="match-message" class="mt-1"></div>
                </div>

                <!-- Submit Button -->
                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary btn-lg" id="register-btn">
                        <i class="fas fa-user-plus me-2"></i>Create Account
                    </button>
                </div>

                <!-- Links -->
                <div class="text-center">
                    <p class="mb-1">Already have an account? 
                        <a href="<?php echo base_url('auth/login'); ?>" class="text-decoration-none fw-semibold">
                            Sign In
                        </a>
                    </p>
                    <p class="mb-0">
                        <a href="<?php echo base_url('auth/resend_verification'); ?>" 
                           class="text-decoration-none text-muted small">
                            Didn't receive verification email?
                        </a>
                    </p>
                </div>

            <?php echo form_close(); ?>
        </div>
    </div>
</div>

<script>
    /**
     * Toggle password visibility
     */
    function togglePassword(fieldId) {
        const field = document.getElementById(fieldId);
        field.type = field.type === 'password' ? 'text' : 'password';
    }

    /**
     * Real-time password strength checker
     */
    function checkPasswordStrength(password) {
        const bar = document.getElementById('strength-bar');
        const text = document.getElementById('strength-text');

        // Check individual requirements and update checklist
        const checks = {
            'req-length':  password.length >= 8,
            'req-upper':   /[A-Z]/.test(password),
            'req-lower':   /[a-z]/.test(password),
            'req-number':  /[0-9]/.test(password),
            'req-special': /[@$!%*?&]/.test(password)
        };

        let passed = 0;

        for (const [id, ok] of Object.entries(checks)) {
            const el = document.getElementById(id);
            if (ok) {
                el.innerHTML = el.innerHTML.replace('fa-times text-danger', 'fa-check text-success');
                passed++;
            } else {
                el.innerHTML = el.innerHTML.replace('fa-check text-success', 'fa-times text-danger');
            }
        }

        // Update strength bar
        bar.className = 'password-strength';
        if (password.length === 0) {
            bar.style.width = '0';
            text.textContent = '';
        } else if (passed <= 1) {
            bar.classList.add('strength-weak');
            text.textContent = 'Weak';
            text.style.color = '#dc3545';
        } else if (passed <= 2) {
            bar.classList.add('strength-fair');
            text.textContent = 'Fair';
            text.style.color = '#ffc107';
        } else if (passed <= 4) {
            bar.classList.add('strength-good');
            text.textContent = 'Good';
            text.style.color = '#198754';
        } else {
            bar.classList.add('strength-strong');
            text.textContent = 'Strong ✓';
            text.style.color = '#0d6efd';
        }
    }

    /**
     * Check if passwords match in real time
     */
    function checkPasswordMatch() {
        const pwd = document.getElementById('password').value;
        const cpwd = document.getElementById('confirm_password').value;
        const msg = document.getElementById('match-message');

        if (cpwd.length === 0) {
            msg.innerHTML = '';
        } else if (pwd === cpwd) {
            msg.innerHTML = '<small class="text-success"><i class="fas fa-check me-1"></i>Passwords match</small>';
        } else {
            msg.innerHTML = '<small class="text-danger"><i class="fas fa-times me-1"></i>Passwords do not match</small>';
        }
    }

    // Prevent double submit
    document.querySelector('form').addEventListener('submit', function() {
        const btn = document.getElementById('register-btn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Creating Account...';
    });
</script>

<?php $this->load->view('layouts/auth_footer'); ?>