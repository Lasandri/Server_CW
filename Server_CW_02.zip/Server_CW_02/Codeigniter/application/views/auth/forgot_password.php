<?php
// Codeigniter/application/views/auth/forgot_password.php
$page_title = 'Forgot Password - Alumni Dashboard';
$this->load->view('layouts/auth_header');
?>

<div class="row justify-content-center w-100">
    <div class="col-12">
        <div class="auth-card mx-auto">

            <div class="auth-logo">
                <i class="fas fa-key fa-3x text-warning mb-3"></i>
                <h2>Forgot Password?</h2>
                <p>Enter your university email and we'll send a reset link</p>
            </div>

            <!-- Success Message -->
            <?php if (isset($message)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
                <div class="text-center">
                    <a href="<?php echo base_url('auth/login'); ?>" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt me-2"></i>Back to Login
                    </a>
                </div>
            <?php else: ?>

                <?php if (isset($errors)): ?>
                    <div class="alert alert-danger">
                        <?php echo $errors; ?>
                    </div>
                <?php endif; ?>

                <?php echo form_open('auth/forgot_password_submit'); ?>

                    <div class="mb-4">
                        <label for="email" class="form-label fw-semibold">University Email</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-envelope text-muted"></i>
                            </span>
                            <input type="email" 
                                   class="form-control" 
                                   id="email" 
                                   name="email"
                                   placeholder="w123456789@my.westminster.ac.uk"
                                   required autofocus>
                        </div>
                    </div>

                    <div class="d-grid mb-3">
                        <button type="submit" class="btn btn-warning btn-lg fw-semibold">
                            <i class="fas fa-paper-plane me-2"></i>Send Reset Link
                        </button>
                    </div>

                    <div class="text-center">
                        <a href="<?php echo base_url('auth/login'); ?>" 
                           class="text-decoration-none text-muted">
                            <i class="fas fa-arrow-left me-1"></i>Back to Login
                        </a>
                    </div>

                <?php echo form_close(); ?>

            <?php endif; ?>
        </div>
    </div>
</div>

<?php $this->load->view('layouts/auth_footer'); ?>