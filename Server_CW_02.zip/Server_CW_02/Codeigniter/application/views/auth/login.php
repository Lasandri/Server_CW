<?php
// Codeigniter/application/views/auth/login.php
$page_title = 'Login - Alumni Dashboard';
$this->load->view('layouts/auth_header');
?>

<div class="row justify-content-center w-100">
    <div class="col-12">
        <div class="auth-card mx-auto">

            <div class="auth-logo">
                <i class="fas fa-chart-line fa-3x text-primary mb-3"></i>
                <h2>Alumni Dashboard</h2>
                <p>University Analytics Portal</p>
            </div>

            <!-- Flash Messages -->
            <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
            <?php endif; ?>

            <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    <?php echo $this->session->flashdata('error'); ?>
                </div>
            <?php endif; ?>

            <!-- Login Error -->
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle me-2"></i>
                    <?php echo htmlspecialchars($error); ?>

                    <!-- Show resend verification link if needed -->
                    <?php if (isset($show_resend) && $show_resend): ?>
                        <br>
                        <a href="<?php echo base_url('auth/resend_verification'); ?>" 
                           class="alert-link">
                            Click here to resend verification email
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <?php echo form_open('auth/login_submit'); ?>

                <!-- Email Field -->
                <div class="mb-3">
                    <label for="email" class="form-label fw-semibold">University Email</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-envelope text-muted"></i>
                        </span>
                        <input type="email" 
                               class="form-control" 
                               id="email" 
                               name="email"
                               placeholder="w123456789@my.westminster.ac.uk"
                               value="<?php echo isset($email) ? htmlspecialchars($email) : set_value('email'); ?>"
                               required 
                               autofocus>
                    </div>
                </div>

                <!-- Password Field -->
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <label for="password" class="form-label fw-semibold mb-0">Password</label>
                        <a href="<?php echo base_url('auth/forgot_password'); ?>" 
                           class="text-decoration-none small text-primary">
                            Forgot Password?
                        </a>
                    </div>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-lock text-muted"></i>
                        </span>
                        <input type="password" 
                               class="form-control" 
                               id="password" 
                               name="password"
                               placeholder="Enter your password"
                               required>
                        <button class="btn btn-outline-secondary" type="button"
                                onclick="togglePassword('password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <!-- Submit -->
                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary btn-lg" id="login-btn">
                        <i class="fas fa-sign-in-alt me-2"></i>Sign In
                    </button>
                </div>

                <div class="text-center">
                    <p class="mb-0">Don't have an account? 
                        <a href="<?php echo base_url('auth/register'); ?>" 
                           class="text-decoration-none fw-semibold text-primary">
                            Register here
                        </a>
                    </p>
                </div>

            <?php echo form_close(); ?>
        </div>
    </div>
</div>

<script>
    function togglePassword(id) {
        const f = document.getElementById(id);
        f.type = f.type === 'password' ? 'text' : 'password';
    }

    document.querySelector('form').addEventListener('submit', function() {
        const btn = document.getElementById('login-btn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Signing In...';
    });
</script>

<?php $this->load->view('layouts/auth_footer'); ?>