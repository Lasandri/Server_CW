<?php
// Codeigniter/application/views/auth/reset_password.php
$page_title = 'Reset Password - Alumni Dashboard';
$this->load->view('layouts/auth_header');
?>

<div class="row justify-content-center w-100">
    <div class="col-12">
        <div class="auth-card mx-auto">

            <div class="auth-logo">
                <i class="fas fa-shield-alt fa-3x text-success mb-3"></i>
                <h2>Set New Password</h2>
                <p>Create a strong password for your account</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-times-circle me-2"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <br><br>
                    <a href="<?php echo base_url('auth/forgot_password'); ?>" class="alert-link">
                        Request a new reset link
                    </a>
                </div>
            <?php endif; ?>

            <?php if (isset($errors)): ?>
                <div class="alert alert-warning">
                    <?php echo $errors; ?>
                </div>
            <?php endif; ?>

            <?php echo form_open('auth/reset_password_submit'); ?>

                <!-- Hidden token field -->
                <input type="hidden" name="token" 
                       value="<?php echo htmlspecialchars(isset($token) ? $token : ''); ?>">

                <!-- New Password -->
                <div class="mb-3">
                    <label for="password" class="form-label fw-semibold">New Password</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-lock text-muted"></i>
                        </span>
                        <input type="password" 
                               class="form-control" 
                               id="password" 
                               name="password"
                               placeholder="Min. 8 characters"
                               required
                               oninput="checkPasswordStrength(this.value)">
                        <button class="btn btn-outline-secondary" type="button"
                                onclick="togglePassword('password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                    <div class="password-strength" id="strength-bar"></div>
                    <small id="strength-text"></small>
                </div>

                <!-- Confirm New Password -->
                <div class="mb-4">
                    <label for="confirm_password" class="form-label fw-semibold">Confirm New Password</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-lock text-muted"></i>
                        </span>
                        <input type="password" 
                               class="form-control" 
                               id="confirm_password" 
                               name="confirm_password"
                               placeholder="Repeat new password"
                               required
                               oninput="checkPasswordMatch()">
                    </div>
                    <div id="match-message" class="mt-1"></div>
                </div>

                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-success btn-lg fw-semibold">
                        <i class="fas fa-save me-2"></i>Reset Password
                    </button>
                </div>

            <?php echo form_close(); ?>
        </div>
    </div>
</div>

<script>
    /* Same password helpers as register page */
    function togglePassword(id) {
        const f = document.getElementById(id);
        f.type = f.type === 'password' ? 'text' : 'password';
    }

    function checkPasswordStrength(password) {
        const bar = document.getElementById('strength-bar');
        const text = document.getElementById('strength-text');
        const passed = [
            password.length >= 8,
            /[A-Z]/.test(password),
            /[a-z]/.test(password),
            /[0-9]/.test(password),
            /[@$!%*?&]/.test(password)
        ].filter(Boolean).length;

        bar.className = 'password-strength';
        if (passed <= 1)      { bar.classList.add('strength-weak');   text.textContent = 'Weak';   text.style.color = '#dc3545'; }
        else if (passed <= 2) { bar.classList.add('strength-fair');   text.textContent = 'Fair';   text.style.color = '#ffc107'; }
        else if (passed <= 4) { bar.classList.add('strength-good');   text.textContent = 'Good';   text.style.color = '#198754'; }
        else                  { bar.classList.add('strength-strong'); text.textContent = 'Strong'; text.style.color = '#0d6efd'; }
    }

    function checkPasswordMatch() {
        const pwd = document.getElementById('password').value;
        const cpwd = document.getElementById('confirm_password').value;
        const msg = document.getElementById('match-message');
        if (!cpwd) { msg.innerHTML = ''; return; }
        msg.innerHTML = pwd === cpwd
            ? '<small class="text-success"><i class="fas fa-check me-1"></i>Passwords match</small>'
            : '<small class="text-danger"><i class="fas fa-times me-1"></i>Passwords do not match</small>';
    }
</script>

<?php $this->load->view('layouts/auth_footer'); ?>